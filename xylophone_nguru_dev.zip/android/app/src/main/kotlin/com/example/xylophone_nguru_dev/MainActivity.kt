package com.example.xylophone_nguru_dev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
